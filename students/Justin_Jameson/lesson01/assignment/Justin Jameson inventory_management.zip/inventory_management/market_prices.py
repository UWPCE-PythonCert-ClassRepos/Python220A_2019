""" Market Prices """


def get_latest_price(item_code):
    """ I think this should be the magic mock?
    Not sure exactly what is happening here"""
    return 24
    # Raise an exception to force the user to Mock its output
