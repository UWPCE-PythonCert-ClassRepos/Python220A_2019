#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created 5/26/2019

@author: Russell Large
"""


import csv
import logging_code
from functools import partial

LOGGER = logging_code.log_your_stuff()

def add_furniture(customer_name, item_code, item_description, item_monthly_price, invoice_file=None):
    '''
    :param customer_name: Name of customer specified in argument.
    :param item_code: Code of item specified in argument.
    :param item_description: Description of the item specified in argument.
    :param item_monthly_price: Price of item to rent.
    :param invoice_file: optional argument. by default will created 'rented_items.csv'
    :return: no return.
    '''

    add_data = [customer_name, item_code, item_description, item_monthly_price]

    test_write_data = 0

    if invoice_file is None:
        LOGGER.info('Invoice file marked as None. Creating rental_items.csv.')
        with open('rental_items.csv', 'a', newline='') as csvfile:
            datawriter = csv.writer(csvfile, delimiter=',')
            datawriter.writerow(add_data)
            test_write_data += 1
    else:
        LOGGER.info(f'Invoice file specified. adding data to {invoice_file}.')
        with open(invoice_file, 'a', newline='') as csvfile:
            datawriter = csv.writer(csvfile, delimiter=',')
            datawriter.writerow(add_data)
            test_write_data += 1

    return test_write_data, add_data

def single_customer(customer_name, items_csv):
    '''
    This function uses a closure so the customer name and items to be added
    are 'fixed', and can be added to the rental_items csv.
    :param customer_name:
    :param items_csv:
    :return:
    '''

    customer_data = []
    with open(items_csv, 'r', newline='') as csvfile:
        datareader = csv.reader(csvfile, delimiter=',')
        try:
            for row in datareader:
                customer_data.append(row)
        except TypeError:
            LOGGER.warning(f'Type Error raised reading {items_csv}.')

    def rental_item(invoice_file):
        nonlocal customer_data
        TestList = []
        try:
            for item in customer_data:
                add_furniture(customer_name, item[0], item[1], item[2], invoice_file=invoice_file)
                data_tester = (customer_name, item[0], item[1], item[2], invoice_file)
                print(data_tester)
                TestList.append(data_tester)
            LOGGER.info('data has been added')
        except IndexError:
            LOGGER.warning('Index error')
        return TestList


    return rental_item

new = partial(single_customer('Susan Wong', 'test_items.csv'))
test = new('SusanWong_Invoice.csv')

