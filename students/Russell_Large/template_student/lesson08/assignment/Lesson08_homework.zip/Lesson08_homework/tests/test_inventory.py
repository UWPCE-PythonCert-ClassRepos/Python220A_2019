#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created 5/26/2019

@author: Russell Large
"""

import pytest
import sys
import os
from functools import partial


src = os.getcwd()[:-5] + '\src'
sys.path.append(src)

# append path for logger
log_imp = 'C:\Python220'
sys.path.append(log_imp)

import logging_code
import inventory as l


# Testing parameters
invoice_file = 'test_invoice_file.csv'
customer_name = 'Elisa Miles'
item_code = 'LR01'
item_description = 'Leather Sofa'
item_monthly_price = 25.00
test_items = 'test_items.csv'

# Possibly add a way to test batch update to add_furniture function
@pytest.fixture
def test_data():
    return [('Elisa Miles','LR04','Leather Sofa',25.0),
            ('Edward Data','KT78','Kitchen Table',10.0),
            ('Alex Gonzales','BR02','Queen Mattress',17.0)]

def test_add_furniture():

    test_it = l.add_furniture(customer_name, item_code,
                    item_description, item_monthly_price, invoice_file)

    # Test items written to csv file
    assert test_it[0] > 0

    # Test individual items
    assert test_it[1][0] == customer_name
    assert test_it[1][1] == item_code
    assert test_it[1][2] == item_description
    assert test_it[1][3] == item_monthly_price

def test_single_customer():

    set_up = partial(l.single_customer(customer_name, test_items))
    test_it = set_up('testing.csv')

    # test output of nested function
    assert test_it[0][0] == customer_name
    assert test_it[0][1] == item_code
    assert test_it[1][2] == 'Television'
    assert test_it[1][3] == '28.00'
    assert test_it[1][4] == 'testing.csv'

