import argparse
import json
import datetime
import math
import os
import logging

def log_decorator(func):
    import logging
    import logging_code

    # create a logger under the python file name
    base = os.path.basename(os.path.abspath(__file__))
    file_name = os.path.splitext(base)[0]
    LOGGER = logging_code.log_your_stuff(f'{file_name}.log')

    def wrapper_func(*args, **kwargs):
        # LOGGER.info(f"wrapper executed this before {func.__name__}")

        if func.__name__ == 'load_rentals_file':

            try:
                LOGGER.info('Parser arguments successfully loaded. Loading arguments into memory...')
                return func(*args, **kwargs)
            except FileNotFoundError as f:
                LOGGER.exception(f)

            LOGGER.info(f'{func.__name__} had successfully. ')

        elif func.__name__ == 'parse_cmd_arguments':

            try:
                LOGGER.info("Arguments passed to parser.")
                return func(*args, **kwargs)

            except TypeError:
                pass
                LOGGER.error(f'Add Argument to parser failed. incorrect argument'
                             f' {func}')
            except ValueError:
                LOGGER.error(f"Add argument to parser failed. incorrect argument."
                             f"{func}")

            LOGGER.info(f"input/output added successfully.")


        elif func.__name__ == 'calculate_additional_fields':
            try:
                LOGGER.info('Calculating fields...')
                return func(*args, **kwargs)
            except ValueError as e:
                LOGGER.info('Field not calculated correctly.')
                LOGGER.exception(e)

        elif func.__name__ == 'save_to_json':
            try:
                LOGGER.info("Fields calculated correctly. Adding data to json file...")
                return func(*args, **kwargs)

            except ValueError:
                LOGGER.warning('Data not saved correctly.')

        else:
            try:
                return func(*args, **kwargs)
            except Exception:
                err = "there was an exception in "
                err += func.__name__

                LOGGER.error(err)
                LOGGER.exception(err)

    return wrapper_func


def parse_cmd_arguments():
    '''This function will add arguments added from command line.'''
    parser = argparse.ArgumentParser(description=
                                     'Process some integers.')
    parser.add_argument('-i', '--input',
                        help='input JSON file', required=True)
    parser.add_argument('-o', '--output',
                        help='ouput JSON file', required=True)

    # logging.debug("{} has been added successfully")

    return parser.parse_args()

def load_rentals_file(filename):
    '''This function will take all calculated data and add it
       to the specified args file'''
    with open(filename) as file:
        try:
            data = json.load(file)
        except ValueError:
            exit(0)
    return data

def calculate_additional_fields(data):
    '''Calculate the data from the input json file. '''
    for value in data.values():
        try:
            rental_start = datetime.datetime.strptime(value['rental_start'], '%m/%d/%y')
            rental_end = datetime.datetime.strptime(value['rental_end'], '%m/%d/%y')
            value['total_days'] = (rental_end - rental_start).days
            value['total_price'] = value['total_days'] * value['price_per_day']
            value['sqrt_total_price'] = math.sqrt(value['total_price'])
            value['unit_cost'] = value['total_price'] / value['units_rented']

            #logging.debug("{} has been calculated. ".format(value['product_code']))

            # return value['product_code']

        except ValueError:
            with open('errordata.txt', 'a') as er:
                er.write(str(value))
                er.write('\n')
        except:
            exit(0)

    return data

def save_to_json(filename, data):
    '''Save all data and dump it to the file. '''
    try:
        with open(filename, 'w') as file:
            json.dump(data, file)

    except ValueError:
        pass
        # logging.error("data not saved to json output correctly.")


if __name__ == "__main__":

    import sys

    while True:
        logger_question = input("Would you like to use a logger? (y/n): ")
        if logger_question.lower() == 'y':

            step1 = log_decorator(parse_cmd_arguments)
            args = step1()

            step2 = log_decorator(load_rentals_file)
            data = step2(args.input)

            step3 = log_decorator(calculate_additional_fields)
            calc = step3(data)

            step4 = log_decorator(save_to_json)
            step4(args.output, data)

            exit = input("data successfully added. would you like to exit? (y/n):")

            if exit == 'y':
                sys.exit()

            else:
                continue

        elif logger_question.lower() == 'n':

            args = parse_cmd_arguments()
            data = load_rentals_file(args.input)
            data = calculate_additional_fields(data)
            save_to_json(args.output, data)

        else:

            print("not a valid entry.")

    # logger_question = input("Would you like to use a logger? (y/n): ")
    # if logger_question.lower() == 'y':
    #     args = log_decorator(parse_cmd_arguments)

