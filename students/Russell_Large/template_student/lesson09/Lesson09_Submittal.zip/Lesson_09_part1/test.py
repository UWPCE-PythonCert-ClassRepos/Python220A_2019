import sys
#
# print(sys.modules[__name__].__file__)


import os
#
base = os.path.basename(os.path.abspath(__file__))
print(os.path.splitext(base)[0])

# os.path.splitext(base)[0]


# print(os.path.abspath(__file__))