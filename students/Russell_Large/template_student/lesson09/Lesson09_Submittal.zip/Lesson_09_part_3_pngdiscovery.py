import os

parent_directory = input("Please enter a directory: ")


def find_images(directory):
    intermediate_folder = []
    final_folder = []
    for root, dirs, files in os.walk(directory, topdown=False):

        for item in dirs:
            folder = os.path.join(root, item)
            file = os.listdir(os.path.join(root, item))
            intermediate_folder.append([folder, file])

    # Attempt to delete any entries that do not contain '.png'
    for item in intermediate_folder:
        for file in item[1]:
            #print(file)
            try:
                if file.__contains__('.png'):
                    # print(item[0])
                    pass
                else:
                    #remove from list of list
                    pass
            except Exception as e:
                pass

    for item in intermediate_folder:
        print(item)

find_images(parent_directory)

