import os

parent_directory = input("Please enter a directory: ")

def find_images(directory):
    pylist = []
    root_folder = []
    full_count = 0


    for root, dirs, files in os.walk(directory, topdown=False):
        for name in dirs:
            root_folder.append(os.path.join(root, name))
            for rname in files:
                if rname.__contains__('.py'):
                    pylist.append([rname])
                    full_count +=1
            root_folder.append(pylist)


    if full_count == 0:
        print("no .png files found in this directory.")

    for item in root_folder:
        print(item)


find_images(parent_directory)

