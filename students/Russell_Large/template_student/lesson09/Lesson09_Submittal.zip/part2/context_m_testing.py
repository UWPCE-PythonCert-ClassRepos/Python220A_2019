import csv
import os
from contextlib import contextmanager


# verify file is csv file

@contextmanager
def verify_file(file):

    try:
        if file.__contains__('.csv'):
            yield True
        else:
            raise RuntimeError
    except RuntimeError:
        print(RuntimeError)


t = 'test_run.csv'
o = 't.cos'

tu = t, o
for item in tu:
    print(item)
    with verify_file(item):
        try:
            print('ok')

            reader = csv.reader(open(t))
            for row in reader:
                print(row)

        except:
            print('no')