import csv
import os
import time
import mongo_connect as monmon
from contextlib import contextmanager

# Add a folder named 'data'
# keep within same folder as this file
db_folder = os.getcwd()
loc = str(db_folder + '\data')
product = f'{loc}\product.csv'
customer = f'{loc}\customer.csv'
rental = f'{loc}\\rental.csv'


class time_records_decorator():
    '''This class is used as a decorative class where a given function will
    be executed with any *args. The name, elapsed time,
    and # of records(if input_data is func) will be written to a 'timings.txt' file.
    '''
    def __init__(self, value):
        self.value = value

    def __call__(self, obj):
        def wrap(*args):
            # Record function name
            name = obj.__name__
            # Get timing
            beg_time = time.time()
            obj(*args)
            end_time = time.time()
            elapsed_time = round((end_time - beg_time), 4)
            # Separate import data vs other functions
            # write to same file
            if name == 'import_data':
                with open('timings.txt', 'a') as f:
                    f.write(f"Function: {name}. "
                            f" Total Execution time: "
                            f"{elapsed_time} seconds."
                            f" Number of Records: {obj(*args)}")
                    f.write("\n")
            else:
                with open('timings.txt', 'a') as f:
                    f.write(f"Function: {name}. "
                            f" Total Execution time: "
                            f"{elapsed_time} seconds.")
                    f.write("\n")
        return wrap

@contextmanager
def verify_file(file):
    ''' This function will throw a RuntimeError
    If the file does not contain '.csv'.'''
    try:
        if file.__contains__('.csv'):
            yield True
        else:
            print(f'{file} is not a csv file.')
    except RuntimeError as r:
        print(r)


@time_records_decorator(1)
def import_data(dir, products, customers, rentals):
    '''
    Import different types of CSV data into MongoDB.
    :param dir:
    :param products:
    :param customers:
    :param rentals:
    :return:
    '''
    mongo = monmon.MongoDBConnection()

    with mongo:
        csvlist = [products, customers, rentals]
        product_dict_list = []
        cust_dict_list = []
        rentals_dict_list = []
        errors = []

        prod_count = []
        cust_count = []
        rentals_count = []

        for file in csvlist:
            if file == products:
                with verify_file(products):
                    errors_count = 0
                    # append csv to dict list
                    reader = csv.reader(open(products, 'r'))

                    try:
                        for row in reader:
                            product_dict = ({
                                    '_id': row[0],
                                    'description': row[1],
                                    'product_type': row[2],
                                    'quantity_available': row[3],
                                    })
                            product_dict_list.append(product_dict)

                        # connect to mongodb, create collection
                        db = mongo.connection.HP_Norton
                        collection = db['Products']
                        collection.drop()

                        # insert data to 'Products' collection
                        result = collection.insert_many(product_dict_list)

                        # produce count from input
                        prod_count = len(result.inserted_ids)

                    except RuntimeError:
                        print(f'{products} is not a csv')
                    except FileNotFoundError as e:
                        print(e)
                        errors_count += 1
                        errors.append('product errors:' + str(errors_count))

            elif file == customers:

                with verify_file(customers):
                    errors_count = 0
                    # append csv to dict list
                    reader = csv.reader(open(customers, 'r'))
                    try:
                        for row in reader:
                            cust_dict = ({'_id': row[0],
                                     'cust_name': row[1],
                                     'cust_address': row[2],
                                     'cust_zip': row[3],
                                     'cust_phone': row[4],
                                     'cust_email': row[5]
                                     })
                            cust_dict_list.append(cust_dict)

                        # connect to mongodb, create collection
                        db = mongo.connection.HP_Norton
                        collection = db['Customer']
                        collection.drop()

                        # insert data to 'Products' collection
                        result = collection.insert_many(cust_dict_list)

                        # produce count from input
                        cust_count = len(result.inserted_ids)

                    except FileNotFoundError as e:
                        print(e)
                        errors_count += 1
                        errors.append('customer errors:' + str(errors_count))

            elif file == rentals:

                with verify_file(rentals):

                    errors_count = 0
                    reader = csv.reader(open(rentals, 'r'))
                    try:
                        # append csv to dict list
                        for row in reader:
                            rentals_dict = ({'product_id': row[0],
                                            'user_id': row[1]
                                            })
                            rentals_dict_list.append(rentals_dict)

                        # connect to mongodb, create collection
                        db = mongo.connection.HP_Norton
                        collection = db['Rentals']
                        collection.drop()

                        # insert data to 'Products' collection
                        result = collection.insert_many(rentals_dict_list)

                        # produce count from input
                        rentals_count = len(result.inserted_ids)

                    except FileNotFoundError as e:
                        print(e)
                        errors_count += 1
                        errors.append('customer errors:' + str(errors_count))

        return prod_count, cust_count, rentals_count

@time_records_decorator(1)
def show_available_products():
    '''
    Query function returns all Product collection data that has a
    'quantity_available' greater than 0. Also returns a 'test'
    variable that helps with testing.
    :return:
    '''
    mongo = monmon.MongoDBConnection()

    with mongo:
        db = mongo.connection.HP_Norton
        collection = db['Products']
        results_dict = {}
        for avail in collection.find({"quantity_available": {'$gt': '0'}}):
            id = avail.pop('_id')
            products = avail['description']
            results_dict[id] = avail
        test = tuple(results_dict.keys())
        return results_dict, test

@time_records_decorator(1)
def show_rentals(product_id):
    '''
    Query function that matches rentals collection data with customer collection
    data from the rentals collection. query will return data that matches.
    :param product_id:
    :return:
    '''
    mongo = monmon.MongoDBConnection()
    results = {}

    with mongo:
        db = mongo.connection.HP_Norton
        rentals = db['Rentals']

        try:
            for info in rentals.aggregate([
                {
                    '$lookup':
                        {
                            'from': 'Customer',
                            'localField': 'user_id',
                            'foreignField': '_id',
                            'as': 'ID'
                        }
                },
                    {'$match': {'product_id': product_id}}]):
                results['Rentals'] = info

        except Exception as e:
            print(e)

    test = f"{results.keys()}"

    return results, test

# Testing functionality
import_data('data', product, customer, rental)
show_available_products()
show_rentals('prd001')

